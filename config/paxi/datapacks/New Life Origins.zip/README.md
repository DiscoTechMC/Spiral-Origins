# New Life Origins

CurseForge link: https://curseforge.com/minecraft/customization/new-life-origins

Modrinth link: https://modrinth.com/project/new-life-origins
